<?php

namespace App\Http\Controllers\admin\asbar_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\fuel_asbar;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;


class FuelAsbarController extends Controller
{
    public function index(Request $request)
    {
         // Ambil input tahun dari request
         $tahun = $request->input('tahun');
         $filterTahun = $request->input('filter_tahun');
         $item = $request->input('item'); // Input filter item
 
         // Query dasar untuk mengambil data
         $query = fuel_asbar::query();
 
         // Filter berdasarkan pencarian tahun
         if ($tahun) {
             $query->whereYear('created_at', $tahun);
         }
         // Filter berdasarkan item
         if ($item) {
             $query->where('item', $item);
         }
         // Filter berdasarkan dropdown filter_tahun
         if ($filterTahun) {
             $query->whereYear('created_at', $filterTahun);
         }
 
         // Ambil data hasil query dan format bulan/tahun
         $dokumenfuelasbar = $query->get()->map(function ($item) {
             $item->bulan_tahun = Carbon::parse($item->created_at)->format('F Y'); // Format Bulan dan Tahun
             return $item;
         });
 
         // Ambil daftar tahun unik untuk dropdown filter
         $tahunList = fuel_asbar::selectRaw('YEAR(created_at) as tahun')->distinct()->pluck('tahun');
 
        return view('rate-contract/asbar/fuelasbar/index',compact('dokumenfuelasbar', 'tahunList'));
    }
    public function tambah()   
    {
        return view('rate-contract/asbar/fuelasbar/tambah');
    }
    public function simpan(Request $request)
    {
        $path = $request->file('contract_reference')->store('img', 'public');

        // simpan data ke database
        fuel_asbar::insert([
            'activity' => $request->activity,
            'item' => $request->item,
            'fuel_index' => $request->fuel_index,
            'distance' => $request->distance,
            'contract_reference' => $path,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect()->to('rate-contract/asbar/fuel-asbar')->with('success', 'Data berhasil ditambahkan');
    }
    public function edit($id)
    {
         // Ambil data berdasarkan ID
         $dokumenfuelasbar = fuel_asbar::findOrFail($id);

         // Kirim data ke view
         return view('rate-contract/asbar/fuelasbar/edit',compact('dokumenfuelasbar'));
    }
    public function update(Request $request, $id)
    {
         // Ambil data berdasarkan ID
         $dokumenfuelasbar = fuel_asbar::findOrFail($id);

         // Update data
         $dokumenfuelasbar->update([
            'activity' => $request->activity,
             'item' => $request->item,
             'fuel_index' => $request->fuel_index,
             'distance' => $request->distance,
             'updated_at' => now(),
         ]);
         return redirect()->to('rate-contract/asbar/fuel-asbar')->with('success', 'Data berhasil diperbarui');
    }
    public function detail($id)
    {
        $dokumenfuelasbar = fuel_asbar::where('id', $id)->get()->first();
        return view('rate-contract/asbar/fuelasbar/detail', compact('dokumenfuelasbar'));
    }

    public function hapus($id)
    {
        $dokumenfuelasbar = fuel_asbar::findOrFail($id);
        $dokumenfuelasbar->delete();

        return redirect()->to('rate-contract/asbar/fuel-asbar');
    }
    
}
